# 文本整理

KDP TypeScript 工具样板：删除空行、去除行首尾空白、合并连续空白。支持中文、英文与 Unicode 文本，最多 100,000 字符；只处理空白和换行，不保存文本。

## 本地开发

需要 Node.js 24。本机开发验证使用 24.16.0；容器基础镜像固定为官方 Node.js 24.18.0 / Debian bookworm-slim 的真实仓库摘要（见 Dockerfile），当前容器验收平台为 arm64。

```sh
npm ci
npm run dev
```

浏览器访问 `http://127.0.0.1:5173`。开发服务仅监听本机，页面显示“本地开发”；该身份不代表已登录公司平台。

```sh
npm run check
npm test
npm run build
npm start
```

最后一条运行构建后的同源服务，默认 `http://127.0.0.1:3000`。页面输入“`  甲    乙`”与空行，整理后应得到“`甲 乙`”；修改规则或输入后旧结果标记过期，重新整理才可复制。

`server/schema.ts` 定义接口，`npm run contracts` 导出 `contracts/openapi.json` 并生成 `contracts/api.d.ts`，前端引用生成类型。不要分别手写相同的请求和响应类型。

## 发布和运行

通过 KDP Skill 与发布助手发布。初始化后由助手写入真实版本锁与规范快照，不手工填写摘要或所有者。发布配置和凭证不放入源码。

生产运行必须由平台提供 `KDP_ENV=production`、`KDP_TOOL_ID`、每工具独立的 `KDP_CONTEXT_SECRET`、`PORT`。容器非 root、监听 `0.0.0.0:$PORT`；业务请求与静态页面均验证平台签名上下文，只允许网关访问容器。`/health/live` 与 `/health/ready` 供平台内部探测。内网模式下平台签名上下文的 `userId=intranet-visitor` 表示匿名访客，不是发布者身份；页面显示“内网可用”。本地开发与所有者访问模式保留独立提示。

收到 SIGTERM 后，服务停止接受新请求并在 10 秒内退出。JSON 日志不记录正文和凭证。本样板不申请数据库或文件能力；增添持久化需要相应平台能力验收后再发布。
