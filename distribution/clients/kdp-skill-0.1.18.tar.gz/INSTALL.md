# KDP Skill 安装包

使用者先读 [README_USER.md](README_USER.md)，了解安装、创建、发布和后续修改的说法。

把本安装包交给 Agent，并说：

> 读取安装包中的 INSTALL_AGENT.md，按照说明帮我安装 KDP，并验证内网连接。

Agent 执行入口：[INSTALL_AGENT.md](INSTALL_AGENT.md)。说明包含固定公司入口、环境检查、安装命令、开发与发布流程、换机恢复和出错处理。默认只安装；需要同时开发或发布时，在同一条请求中说明工具需求。

需要 Node.js 24 和 npm。工具在公司内网免登录使用；首次发布自动保存个人凭据，不需要手动登录。客户端不需要安装 Docker 或 SSH 到服务器。不要分发个人凭据或工具的私有运行记录。
