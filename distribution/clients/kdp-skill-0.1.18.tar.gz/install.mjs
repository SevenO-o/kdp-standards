import { cp, mkdir, readFile, writeFile, access, rename } from 'node:fs/promises';
import { homedir } from 'node:os';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
const base = dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const value = flag => { const i = args.indexOf(flag); return i < 0 ? undefined : args[i + 1]; };
const platformId = value('--platform-id'); const platformUrl = value('--platform-url'); const indexUrl = value('--index-url');
if (!platformId || !platformUrl || !indexUrl) {
  console.log('Usage: node install.mjs --platform-id ID --platform-url HTTPS_URL --index-url SOURCE_URL [--skill-dir PATH] [--allow-local-dev | --allow-intranet-http] [--replace]');
  process.exit(1);
}
if (Number(process.versions.node.split('.')[0]) !== 24) throw Error('KDP requires Node.js 24');
const source = join(base, 'kdp');
await access(join(source, 'SKILL.md'));
const target = resolve(value('--skill-dir') || join(homedir(), '.codex/skills/kdp'));
let exists = false; try { await access(target); exists = true; } catch {}
if (exists && !args.includes('--replace')) throw Error('SKILL_ALREADY_EXISTS: use a separate directory or --replace to retain a backup and replace this Skill');
let transportArgs = [];
try { await access(join(base, 'api-transport.json')); transportArgs = ['--api-transport-file', join(base, 'api-transport.json')]; } catch {}
// Validate company configuration using the packaged helper before installing its discovery entry.
const bootstrap = spawnSync(process.execPath, [join(source, 'scripts/kdp.mjs'), 'bootstrap', ...transportArgs, '--platform-id', platformId, '--platform-url', platformUrl, '--index-url', indexUrl, ...(args.includes('--allow-local-dev') ? ['--allow-local-dev'] : []), ...(args.includes('--allow-intranet-http') ? ['--allow-intranet-http'] : [])], { stdio: 'inherit' });
if (bootstrap.status !== 0) process.exit(bootstrap.status || 1);
await mkdir(dirname(target), { recursive: true });
if (exists) await rename(target, `${target}.backup-${Date.now()}`);
await cp(source, target, { recursive: true, errorOnExist: true, force: false });
console.log(JSON.stringify({ state: 'installed', skill: target, next: 'Reload Agent skill discovery, then say 创建 KDP 工具 and describe its purpose' }));
