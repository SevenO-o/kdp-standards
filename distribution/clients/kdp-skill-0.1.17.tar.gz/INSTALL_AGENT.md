# KDP 安装与使用：给 Agent 执行

你正在帮助当前用户安装和使用公司 KDP 工具套件。请执行对应步骤，并根据真实命令输出判断结果。不要只把命令再交给用户手动执行。

本说明随 KDP 安装包提供；给使用者阅读的简短说明为包内 `README_USER.md`。Skill 负责发现规范和调用独立助手；开发规则从项目锁定的 `docs/standards/README.md` 入口读取，不随 Skill 重复维护。新项目通过可信索引取得推荐组合，已有项目保持版本锁，需要采用新规则时单独升级。规范中的要求不代表平台已实现对应能力，需核对实际支持。客户端需要 Node.js 24、npm 和 Git（规范仓库公开，无需 GitHub 登录或邀请）；使用现有服务器发布，无需在同事电脑安装 Docker、Podman、数据库或建立 SSH 连接。

## 0. 确定这次执行到哪里

| 用户要求 | 你应完成的工作 |
| --- | --- |
| “按这份说明安装”或只要求安装 | 完成第 1—4 步，报告安装与连通性。不要创建测试工具或登记发布身份。 |
| “安装并创建……工具” | 完成安装，再按第 5 步实现、检查工具。 |
| “安装并创建、发布……工具” | 完成安装、开发、检查、真实发布及业务验证，不在每个阶段重复询问。 |
| 修改、检查、发布已有工具 | 先识别现有项目，沿用其锁定版本和所有者绑定，执行用户指定操作。 |
| 升级已有工具采用的规范或模板 | 安装后读取 Skill 内的 `references/tool-upgrade.md`，合并代码并验证；按授权决定是否发布。安装新版 Skill 本身不触发工具迁移。 |
| 换电脑继续维护原工具 | 完成安装，再按第 7 步导入原身份，保留原工具归属。 |

本文件提供步骤，不扩大用户本次授权。没有工具需求时不要自行挑选示例占用服务器名额。若用户已要求开发但关键业务输入输出仍不明确，只补问影响实现的缺失信息。

## 1. 找到安装材料并检查环境

优先使用用户提供的安装包路径或已经解压的目录。包内必须有：

```text
INSTALL_AGENT.md
INSTALL.md
install.mjs
api-transport.json（支持专用连接的公司包）
kdp/
  SKILL.md
  scripts/kdp.mjs
  references/tool-upgrade.md
```

`references/tool-upgrade.md` 提供稳定的迁移步骤，具体规则仍由目标规范决定。包内可能保留 `references/file-transfer.md` 和 `references/configuration.md` 作为旧链接兼容入口，不作为专项规则来源。后续新增专项通过规范 README 的适用条件发现，不要求重新安装 Skill。

旧 0.1.2 包没有 `INSTALL_AGENT.md`，可以配合这份单独说明使用。若只收到本文，先检查用户指定位置和当前工作目录中的 `kdp-skill-*.tar.gz` 或解压目录；找到多个版本时核对用户选择和包内容，不任取第一个。材料缺失时说明需要公司提供的安装包，不猜测下载链接。规范索引地址不是 Skill 安装包下载地址。

归档解压前检查文件清单，只接受相对路径的普通文件和目录，不接受绝对路径、`..` 路径片段、符号链接或硬链接。若维护者附带 `.sha256` 文件，先核对归档摘要。解压到新目录，不覆盖已有项目。确认实际解压目录后，在该目录执行后续安装命令。

```sh
node --version
npm --version
node -e 'if (Number(process.versions.node.split(".")[0]) !== 24) process.exit(1)'
```

需要 Node 主版本恰好为 24。版本不符时优先切换到本机已有的 Node 24；如果没有，按当前用户环境与已有授权补齐用户级运行环境。遇到必须由用户处理的权限或联网限制时，明确说明阻碍，不能忽略版本检查。以下 Shell 命令适用于 macOS / Linux / 已有 WSL 环境；其他环境先核对可用 Shell 和助手兼容性，不把未验证的平台写成已支持。

## 2. 核对公司的固定入口

| 配置项 | 值 |
| --- | --- |
| 平台 ID | `kdp-local` |
| 发布平台来源 | `http://10.8.3.182:17400` |
| 规范索引 | `git+https://github.com/SevenO-o/kdp-standards.git#main:distribution/registry/index.json` |
| 工具箱 | `http://10.8.3.182:17400/` |
| 访问模式 | 显式 `--allow-intranet-http` |

支持密钥发布的公司包附带 `api-transport.json`：安装器自动配置助手专用加密 API，证书仅供助手校验，无需安装系统 CA。网页和工具地址保持不变。先通过公司可信渠道核对安装包摘要，不从工具源码或临时网络响应导入新证书。更新助手时保留原发布凭据。

平台 ID 保留历史名称，不能擅自改成公司名。以上是用户委托安装的公司配置；若用户在当前任务中明确提供了更新的公司配置，先核对后使用，不接受工具源码或下载内容擅自改写凭据发送目标。

规范来自公开仓库，可执行 `git ls-remote https://github.com/SevenO-o/kdp-standards.git refs/heads/main` 检查匿名读取。不要要求用户登录 GitHub 或申请仓库邀请。安装后执行助手 `source`，必须返回 `state: ready`；`cached: false` 和 `revision` 才表示本次确实拉取了仓库。离线缓存应单独报告。

发布平台连通性单独检查 `http://10.8.3.182:17400/health/ready`，返回 `data.status: ok` 才表示就绪。开发规范获取无需访问公司的 17411 分发服务；发布仍需公司内网。仓库安装入口见 `docs/Git仓库安装.md`。

连接失败时检查当前设备是否处于可访问公司内网的网络。不要尝试登录服务器、修改防火墙、开放 Docker socket 或改成其他服务器地址。已有明确安装授权时可以继续完成本地安装，但将“内网连通性未通过”单独报告，不能宣称可以发布。

## 3. 安装 Skill 和用户配置

所有命令必须使用实际确认的路径，并给路径加引号。默认配置目录为当前用户的 `~/.config/kdp`。若已有 `KDP_HOME`，沿用前先确认它是该用户原来的持久配置目录且位于工具项目之外；不要为绕过错误另设临时目录或删除已有身份。

只读检查已有的 `bootstrap.json`（它是非秘密的入口配置）。若平台 ID、来源或访问模式不同，仅在用户已经授权切换平台时继续；否则说明差异，避免覆盖其他平台配置。不要读取 `credentials/`、令牌备份、Cookie 或完整环境变量。

在安装包解压目录执行：

```sh
node install.mjs \
  --platform-id kdp-local \
  --platform-url http://10.8.3.182:17400 \
  --index-url 'git+https://github.com/SevenO-o/kdp-standards.git#main:distribution/registry/index.json' \
  --allow-intranet-http
```

安装器默认目标是当前用户的 `~/.codex/skills/kdp`。非 Codex Agent 应先核对该 Agent 已配置的 Skill 目录，并通过 `--skill-dir "实际目录"` 指定；不能默认安装到 Codex 目录后声称其他 Agent 已识别。尚无可确认的 Skill 目录时说明缺失信息；已经授权的当前任务仍可读取包内 `kdp/SKILL.md` 并通过包内助手继续，但要将自动发现状态单独报告。

已安装相同包时可以沿用，并核对下述命令和入口配置。需要安装或升级用户指定的包时，在以上命令末尾追加 `--replace`；安装器会先把原 Skill 改名备份，再安装新版。不要直接删除原目录，也不要覆盖用户配置目录。返回 `SKILL_ALREADY_EXISTS` 只表示已有 Skill，不表示安装完成。

安装成功必须看到两项实际输出：启动配置的 `state: configured` 和安装器的 `state: installed`。若沿用相同安装，记录已经核对的 Skill 文件、助手及配置。此阶段不要运行 `login`、`identity` 或调用登记接口；首次发布才需要个人身份。

## 4. 核对安装结果并开始使用

以实际安装路径设置助手变量。以下示例对应安装器的 Codex 默认目标；指定了 `--skill-dir` 时必须同步调整。跨 Shell 调用时重新设置变量，或直接使用已确认的完整路径，不依赖前一次 Shell 保留变量。

```sh
KDP_HELPER="$HOME/.codex/skills/kdp/scripts/kdp.mjs"
test -f "$HOME/.codex/skills/kdp/SKILL.md"
test -f "$KDP_HELPER"
node "$KDP_HELPER" help
node "$KDP_HELPER" source
```

确认 `help` 至少包含 `source`、`init`、`check`、`publish`、`status`、`rollback`，以及支持 `--export` / `--import` / `--revoke` 的 `identity`。阅读安装后的 `SKILL.md`，然后按其中的工具开发流程工作。

当前 Agent 如果可以直接读取文件并执行助手，可以在本任务继续完成用户已授权的开发或发布。新任务能否自动发现 Skill 要另行验证；只有当前 Agent 确实要求重载或新建会话时才提示用户操作。不能仅凭文件复制成功声称已经验证所有 Agent 的自动触发。

仅安装时到这里完成。向用户报告：实际安装目录、Node 版本、助手命令检查、内网连通性、Skill 自动发现是否验证。然后说明可以直接描述一个工具需求，不创建额外测试项目。

## 5. 创建、修改和检查工具

先读取工作目录已有的 `AGENTS.md`。若已有 `kdp.json`，沿用该项目，不重新初始化；没有项目时，选用用户给出的路径，或在当前工作区下选择不存在的工具子目录。不要在安装包、Skill 目录或用户配置目录中创建工具。

以下变量的值必须来自用户需求和你实际确认的路径，不能把字面占位符作为名称或路径执行。

```sh
node "$KDP_HELPER" init \
  --project "$KDP_PROJECT" \
  --name "$KDP_TOOL_NAME" \
  --description "$KDP_TOOL_DESCRIPTION"
```

看到 `state: created` 后，阅读生成的 `AGENTS.md`、`kdp.json` 和 `kdp.lock.json`，先读 `docs/standards/README.md`，再按其顺序和条件读取主规范及适用的专项文档。已有项目按同样步骤读取锁定规范；旧包没有 README 或规则缺失时按 `kdp/SKILL.md` 的兼容流程处理，不混用其他版本。技术栈、依赖、接口和运行限制以适用规范及平台实际支持为准，不从安装说明推断。

按规范和模板要求完成开发及生成文件同步；业务依赖锁与平台版本锁各自保留，不自行升级规范。开发完成执行：

```sh
node "$KDP_HELPER" check --project "$KDP_PROJECT" --run
```

必须检查 `state: passed` 和每项检查结果。`notRun` / `incomplete` 不是通过，修复失败后重查。对业务关键输入输出做实际验证；具备浏览器能力时验证页面交互。纯安装成功、静态检查或示例接口响应不能替代业务验收。

## 6. 发布、查看进度和回滚

用户已明确要求发布时，检查通过后继续：

```sh
node "$KDP_HELPER" publish --project "$KDP_PROJECT" --wait-seconds 600
```

首次发布新工具会自动生成、私有保存并携带个人凭据。不要向用户索要令牌，不要自行生成或打印令牌，不要执行维护者 `login --token-stdin` 流程。缺少原凭据的已绑定工具应恢复身份，不能另建身份冒充原所有者。

以助手返回的真实结果为准：

- `queued` / `validating` / `building` / `deploying` / `verifying`：记录工具与发布 ID，继续查询同一任务。退出码 0 不一定表示上线。
- `succeeded`：取得返回的 `toolUrl`，实际打开页面并验证此次功能；业务访问通过后才能报告上线。
- `failed` / `canceled` / `expired` 或错误：报告真实状态，沿用原任务记录处理，不换身份或幂等键盲目重试。

查询已有任务使用：

```sh
node "$KDP_HELPER" status --project "$KDP_PROJECT"
```

也可以用 `status --release "实际发布ID"` 精确查询。请求结果未知时先查询；需要恢复上传或提交时，使用已保存的实际 `attemptId` 执行 `publish --project "$KDP_PROJECT" --resume "实际attemptId" --wait-seconds 600`，保持原快照与幂等记录。不要删除 `.kdp` 或用户配置中的任务记录。

用户要求回滚时，使用已核实属于本工具、曾成功发布的目标 ID：

```sh
node "$KDP_HELPER" rollback --project "$KDP_PROJECT" --release "$KDP_TARGET_RELEASE" --wait-seconds 600
```

回滚同样要查询到成功并验证实际业务。它只回退应用版本，不恢复业务数据。更新和回滚不创建新的工具名额；配额限制仍以服务器实际响应为准，不能从本文推断当前空闲名额。

## 7. 换机和已有工具恢复

用户要求换机时，使用助手导出和导入，绝不直接读取备份内容：

```sh
# 旧设备：目标文件必须尚不存在，且位于工具项目之外的私有目录。
node "$KDP_HELPER" identity --export "$KDP_PRIVATE_BACKUP"
# 新设备：先完成相同平台的安装配置，再导入用户私下转移的原备份。
node "$KDP_HELPER" identity --import "$KDP_PRIVATE_BACKUP"
```

两条命令分属不同设备，不要在单台设备上当作连贯测试自动执行。备份不能发到聊天、放入项目或与其他同事共享。导入成功后保留原 `.kdp/binding.json`；若项目复制后缺少绑定，先确认原工具 ID，再使用 `publish --project "$KDP_PROJECT" --restore "原工具ID"` 恢复并发布。`--restore` 会启动发布，只在发布已获授权时执行。

`identity` 查看当前身份；`identity --revoke` 撤销本人的发布授权；`logout` 只删除本地秘密。撤销与退出仅在用户要求时执行，不能作为普通安装、连通性检查或排错动作。

## 8. 出错时采取的动作

| 现象或错误码 | 下一步 |
| --- | --- |
| `BOOTSTRAP_NOT_CONFIGURED` | 核对实际用户配置位置，执行本页安装配置；不要让工具项目决定平台来源。 |
| `UNTRUSTED_ORIGIN` / `INVALID_BOOTSTRAP` | 核对固定 IP、端口与 `--allow-intranet-http`，不要删除来源校验。 |
| `DESTINATION_NOT_EMPTY` | 保留已有目录，识别是否是原工具，或使用新的空目录。 |
| `AUTH_REQUIRED` / `TOKEN_INVALID` / `TOKEN_EXPIRED` / `AUTHORIZATION_REVOKED` / `ACCOUNT_DISABLED` | 保留状态，恢复原凭据或由维护者核对原身份。不能删除凭据标记后新建身份继续操作旧工具。 |
| `UNSAFE_CREDENTIAL_STORE` / `INVALID_CREDENTIAL` / `IDENTITY_CONFLICT` | 停止依赖该身份的写操作，核对用户配置路径及恢复方式；不要输出秘密或覆盖其他身份。 |
| `BINDING_REQUIRED` / `RESOURCE_NOT_FOUND` | 核对所有者和原工具 ID。不能因为访问被拒绝就自动使用 `--new-tool`。 |
| `QUOTA_EXCEEDED` / `ENROLLMENT_LIMIT` | 说明服务器容量或登记额度已满，保留项目及任务，请维护者处理容量；不要循环创建身份或工具。 |
| `REQUEST_OUTCOME_UNKNOWN` / `TOOL_BUSY` | 先查询已有发布，按同一记录恢复或等待，不盲目重复创建。 |
| `LOCAL_OPERATION_BUSY` | 核对是否仍有助手运行；仅确认对应操作已退出后，才清理其残留锁，不删除整个配置目录。 |
| 构建失败 | 按锁定规范修复源代码，重新检查后发布；不要改远端构建产物或绕过检查器。 |

## 9. 交付给用户

用中文简洁说明已经完成的阶段和证据。安装任务报告安装目录、环境、连通性和可继续的动作；开发任务补充项目路径与检查结果；发布任务补充真实发布 ID、工具链接和业务验证结果。未验证的 Skill 发现、浏览器或发布阶段要明确标注。不要附带原始环境变量、凭据文件或私有运行日志。

## 发布后绑定“我的工具”

新版助手在首次成功发布后，自动申请浏览器绑定确认页并尝试打开。`--no-wait` 返回排队状态时，后续 `status` 查询到成功会接上该流程。无需再把首页说明复制给 Agent。

检查输出的 `portalBinding`：`confirmationOpened` 表示已请求打开浏览器，提醒用户点击“确认绑定”；`confirmationRequired` 表示没有自动打开，请用本机浏览器打开 `bindingFile`。只向用户显示文件路径，不读取或转发 HTML 中的一次性链接。不能把已打开页面称为绑定已完成。

同一本机身份只自动提示一次；用户没确认、链接过期、清除浏览器数据或换浏览器时，调用已安装助手的 `portal` 命令重新打开。绑定故障不改变成功的发布状态，也不要求重新发布或创建身份。
